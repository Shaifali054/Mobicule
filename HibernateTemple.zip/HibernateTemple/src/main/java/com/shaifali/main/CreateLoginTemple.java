package com.shaifali.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.shaifali.bean.LoginTemple;
import com.shaifali.util.HibernateUtil;

public class CreateLoginTemple {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Create student entity object
		LoginTemple loginTemple = new LoginTemple();
		
		loginTemple.setName("Mayank");
		loginTemple.setEmail("mayank03@gmail.com");
		loginTemple.setNumber("9993860490");
		loginTemple.setPayment(null);
		loginTemple.setPassword("mayank123");

		// Create session factory object
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		// getting session object from session factory
		Session session = sessionFactory.openSession();
		// getting transaction object from session object
		session.beginTransaction();

		session.save(loginTemple);
		System.out.println("Inserted Successfully");
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
	}
	
	
}
