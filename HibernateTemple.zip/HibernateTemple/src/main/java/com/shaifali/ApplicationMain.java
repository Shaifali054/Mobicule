package com.shaifali;

public class ApplicationMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//SpringApplication.run(ApplicationMain.class,args);
	}

}
