package com.temple.dao;

import com.temple.model.BookPrasad;

public interface BookPrasadDao {
	public void addBookPrasad(BookPrasad bookPrasad);
}
