package com.temple.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.temple.model.BookPrasad;

@Service
public class BookPrasadServiceImpl implements BookPrasadService {
		
		@Autowired
		private JdbcTemplate jdbcTemplate;
		
		
		@Override
		public void addBookPrasad(BookPrasad bookPrasad) {
			// TODO Auto-generated method stub
			
			String query="Insert Into bookPrasad(TempleName,Amount,Name,Number) VALUES(?,?,?,?)";
			jdbcTemplate.update(query,bookPrasad.getTempleName(),bookPrasad.getAmount(),bookPrasad.getName(),bookPrasad.getNumber());
				
		}
	
		
		
		
		
	}

