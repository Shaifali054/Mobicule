package com.temple.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.temple.model.BookPrasad;

@Transactional
@Repository
public class BookPrasadDoaImpl implements BookPrasadDao{

	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	@Override
	public void addBookPrasad(BookPrasad bookPrasad) {
		// TODO Auto-generated method stub
		
		String query="Insert Into bookPrasad(TempleName,Amount,Name,Number) VALUES(?,?,?,?)";
		jdbcTemplate.update(query,bookPrasad.getTempleName(),bookPrasad.getAmount(),bookPrasad.getName(),bookPrasad.getNumber());
			
	}

}
