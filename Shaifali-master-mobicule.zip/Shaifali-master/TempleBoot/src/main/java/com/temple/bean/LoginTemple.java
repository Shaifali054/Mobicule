package com.temple.bean;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "loginTemple")
public class LoginTemple implements Serializable {
	/**
		 * serialVersionUID
		 */
		private static final long serialVersionUID = 8633415090390966715L;
		//@Id
		//@Column(name = "ID")
		//@GeneratedValue(strategy = GenerationType.IDENTITY)
		//private int id;
		
		@Column(name = "name")
		private String name;
		@Column(name = "email")
		private String email;
		@Column(name = "number")
		private String number;
		@Column(name = "payment")
		private String payment;
		@Column(name = "password")
		private String password;
	
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getNumber() {
			return number;
		}
		public void setNumber(String number) {
			this.number = number;
		}
		public String getPayment() {
			return payment;
		}
		public void setPayment(String payment) {
			this.payment = payment;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		
	
	
}
