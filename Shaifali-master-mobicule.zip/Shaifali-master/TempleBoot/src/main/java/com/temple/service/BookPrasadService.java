package com.temple.service;

import com.temple.model.BookPrasad;

public interface BookPrasadService {
	public void addBookPrasad(BookPrasad bookPrasad); 
}
