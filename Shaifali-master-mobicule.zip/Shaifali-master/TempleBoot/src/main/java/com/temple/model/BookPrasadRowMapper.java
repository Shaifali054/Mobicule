package com.temple.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class BookPrasadRowMapper implements RowMapper<BookPrasad> {

	@Override
	public BookPrasad mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
	
		BookPrasad bookPrasad=new BookPrasad();
		bookPrasad.setTempleName(rs.getString("TempleName"));
		bookPrasad.setAmount(rs.getString("Amount"));
		bookPrasad.setName(rs.getString("Name"));
		bookPrasad.setNumber(rs.getString("Number"));
		return bookPrasad;
				
	}

}
