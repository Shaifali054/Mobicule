package com.temple.service;

import com.temple.model.BookNow;

public interface BookNowService {

	public void addBookNow(BookNow booknow); 
	
	
	
	
}
